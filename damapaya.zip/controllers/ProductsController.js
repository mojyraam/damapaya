var queries = require('../dao/products/products')

var productsController = {}

// show list of products
productsController.list_a1 = (req, res) => {
    queries.findall_a1((err, products) => {
        if (err) {
            console.log('Error:', err)
        } else {
            res.render('../views/product/products', { products_a1: products })
        }
    })
}

productsController.list_a2 = (req, res) => {
    queries.findall_a2((err, products) => {
        if (err) {
            console.log('Error:', err)
        } else {
            res.render('../views/product/products', { products_a2: products })
        }
    })
}

// productsController.list_a1c = (req, res) => {
//     queries.findall_a1c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1c: products })
//         }
//     })
// }

// productsController.list_a1d = (req, res) => {
//     queries.findall_a1d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1d: products })
//         }
//     })
// }

// productsController.list_a1e = (req, res) => {
//     queries.findall_a1e((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1e: products })
//         }
//     })
// }

// productsController.list_a1f = (req, res) => {
//     queries.findall_a1f((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1f: products })
//         }
//     })
// }

// productsController.list_a1g = (req, res) => {
//     queries.findall_a1g((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1g: products })
//         }
//     })
// }

// productsController.list_a1h = (req, res) => {
//     queries.findall_a1h((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1h: products })
//         }
//     })
// }

// productsController.list_a1i = (req, res) => {
//     queries.findall_a1i((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1i: products })
//         }
//     })
// }

// productsController.list_a1j = (req, res) => {
//     queries.findall_a1j((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1j: products })
//         }
//     })
// }

// productsController.list_a1k = (req, res) => {
//     queries.findall_a1k((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1k: products })
//         }
//     })
// }

// productsController.list_a1l = (req, res) => {
//     queries.findall_a1l((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1l: products })
//         }
//     })
// }

// productsController.list_a1m = (req, res) => {
//     queries.findall_a1m((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1m: products })
//         }
//     })
// }

// productsController.list_a1n = (req, res) => {
//     queries.findall_a1n((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1n: products })
//         }
//     })
// }

// productsController.list_a1o = (req, res) => {
//     queries.findall_a1o((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1o: products })
//         }
//     })
// }

// productsController.list_a1p = (req, res) => {
//     queries.findall_a1p((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a1p: products })
//         }
//     })
// }

// productsController.list_a2a = (req, res) => {
//     queries.findall_a2a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2a: products })
//         }
//     })
// }

// productsController.list_a2b = (req, res) => {
//     queries.findall_a2b((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2b: products })
//         }
//     })
// }

// productsController.list_a2c = (req, res) => {
//     queries.findall_a2c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2c: products })
//         }
//     })
// }

// productsController.list_a2d = (req, res) => {
//     queries.findall_a2d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2d: products })
//         }
//     })
// }

// productsController.list_a2e = (req, res) => {
//     queries.findall_a2e((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2e: products })
//         }
//     })
// }

// productsController.list_a2f = (req, res) => {
//     queries.findall_a2f((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2f: products })
//         }
//     })
// }

// productsController.list_a2g = (req, res) => {
//     queries.findall_a2g((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2g: products })
//         }
//     })
// }

// productsController.list_a2h = (req, res) => {
//     queries.findall_a2h((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2h: products })
//         }
//     })
// }

// productsController.list_a2i = (req, res) => {
//     queries.findall_a2i((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2i: products })
//         }
//     })
// }

// productsController.list_a2j = (req, res) => {
//     queries.findall_a2j((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2j: products })
//         }
//     })
// }

// productsController.list_a2k = (req, res) => {
//     queries.findall_a2k((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a2k: products })
//         }
//     })
// }

// productsController.list_a3a = (req, res) => {
//     queries.findall_a3a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3a: products })
//         }
//     })
// }

// productsController.list_a3b = (req, res) => {
//     queries.findall_a3b((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3b: products })
//         }
//     })
// }

// productsController.list_a3c = (req, res) => {
//     queries.findall_a3c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3c: products })
//         }
//     })
// }

// productsController.list_a3d = (req, res) => {
//     queries.findall_a3d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3d: products })
//         }
//     })
// }

// productsController.list_a3e = (req, res) => {
//     queries.findall_a3e((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3e: products })
//         }
//     })
// }

// productsController.list_a3f = (req, res) => {
//     queries.findall_a3f((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3f: products })
//         }
//     })
// }

// productsController.list_a3g = (req, res) => {
//     queries.findall_a3g((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3g: products })
//         }
//     })
// }

// productsController.list_a3h = (req, res) => {
//     queries.findall_a3h((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3h: products })
//         }
//     })
// }

// productsController.list_a3i = (req, res) => {
//     queries.findall_a3i((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3i: products })
//         }
//     })
// }

// productsController.list_a3j = (req, res) => {
//     queries.findall_a3j((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3j: products })
//         }
//     })
// }

// productsController.list_a3k = (req, res) => {
//     queries.findall_a3k((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3k: products })
//         }
//     })
// }

// productsController.list_a3l = (req, res) => {
//     queries.findall_a3l((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3l: products })
//         }
//     })
// }

// productsController.list_a3m = (req, res) => {
//     queries.findall_a3m((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a3m: products })
//         }
//     })
// }

// productsController.list_a4a = (req, res) => {
//     queries.findall_a4a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4a: products })
//         }
//     })
// }

// productsController.list_a4b = (req, res) => {
//     queries.findall_a4b((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4b: products })
//         }
//     })
// }

// productsController.list_a4c = (req, res) => {
//     queries.findall_a4c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4c: products })
//         }
//     })
// }

// productsController.list_a4d = (req, res) => {
//     queries.findall_a4d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4d: products })
//         }
//     })
// }

// productsController.list_a4e = (req, res) => {
//     queries.findall_a4e((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4e: products })
//         }
//     })
// }

// productsController.list_a4f = (req, res) => {
//     queries.findall_a4f((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4f: products })
//         }
//     })
// }

// productsController.list_a4g = (req, res) => {
//     queries.findall_a4g((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4g: products })
//         }
//     })
// }

// productsController.list_a4h = (req, res) => {
//     queries.findall_a4h((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4h: products })
//         }
//     })
// }

// productsController.list_a4i = (req, res) => {
//     queries.findall_a4i((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4i: products })
//         }
//     })
// }

// productsController.list_a4j = (req, res) => {
//     queries.findall_a4j((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4j: products })
//         }
//     })
// }

// productsController.list_a4k = (req, res) => {
//     queries.findall_a4k((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a4k: products })
//         }
//     })
// }

// productsController.list_a5a = (req, res) => {
//     queries.findall_a5a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a5a: products })
//         }
//     })
// }

// productsController.list_a5b = (req, res) => {
//     queries.findall_a5b((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a5b: products })
//         }
//     })
// }

// productsController.list_a5c = (req, res) => {
//     queries.findall_a5c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a5c: products })
//         }
//     })
// }

// productsController.list_a5d = (req, res) => {
//     queries.findall_a5d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a5d: products })
//         }
//     })
// }

// productsController.list_a6a = (req, res) => {
//     queries.findall_a6a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a6a: products })
//         }
//     })
// }

// productsController.list_a6b = (req, res) => {
//     queries.findall_a6b((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a6b: products })
//         }
//     })
// }

// productsController.list_a6c = (req, res) => {
//     queries.findall_a6c((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a6c: products })
//         }
//     })
// }

// productsController.list_a6d = (req, res) => {
//     queries.findall_a6d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a6d: products })
//         }
//     })
// }

// productsController.list_a7a = (req, res) => {
//     queries.findall_a7a((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_a7a: products })
//         }
//     })
// }

// productsController.list_b1 = (req, res) => {
//     queries.findall_b1((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_b1: products })
//         }
//     })
// }

// productsController.list_b2 = (req, res) => {
//     queries.findall_b2((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_b2: products })
//         }
//     })
// }

// productsController.list_b3 = (req, res) => {
//     queries.findall_b3((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_b3: products })
//         }
//     })
// }

// productsController.list_b4 = (req, res) => {
//     queries.findall_b4((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_b4: products })
//         }
//     })
// }

// productsController.list_b5 = (req, res) => {
//     queries.findall_b5((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_b5: products })
//         }
//     })
// }

// productsController.list_c1 = (req, res) => {
//     queries.findall_c1((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_c1: products })
//         }
//     })
// }

// productsController.list_d = (req, res) => {
//     queries.findall_d((err, products) => {
//         if (err) {
//             console.log('Error:', err)
//         } else {
//             res.render('../views/product/products', { products_d: products })
//         }
//     })
// }

module.exports = productsController