var queries = require('../dao/rahsazimadani')

var dashboardController = {}

// show dashboard list
dashboardController.list = (req, res) => {
    queries.findAll
}