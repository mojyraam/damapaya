var Product = require('../../models/Product')

exports.findall_a1 = (prod) => {
    Product.find({ productbranch: "a1" }).exec(prod)
}

exports.findall_a2 = (prod) => {
    Product.find({ productbranch: "a2" }).exec(prod)
}

// exports.findall_a1c = (prod) => {
//     Product.find({ productbranch: "a1c" }).exec(prod)
// }

// exports.findall_a1d = (prod) => {
//     Product.find({ productbranch: "a1d" }).exec(prod)
// }

// exports.findall_a1e = (prod) => {
//     Product.find({ productbranch: "a1e" }).exec(prod)
// }

// exports.findall_a1f = (prod) => {
//     Product.find({ productbranch: "a1f" }).exec(prod)
// }

// exports.findall_a1g = (prod) => {
//     Product.find({ productbranch: "a1g" }).exec(prod)
// }

// exports.findall_a1h = (prod) => {
//     Product.find({ productbranch: "a1h" }).exec(prod)
// }

// exports.findall_a1i = (prod) => {
//     Product.find({ productbranch: "a1i" }).exec(prod)
// }

// exports.findall_a1j = (prod) => {
//     Product.find({ productbranch: "a1j" }).exec(prod)
// }

// exports.findall_a1k = (prod) => {
//     Product.find({ productbranch: "a1k" }).exec(prod)
// }

// exports.findall_a1l = (prod) => {
//     Product.find({ productbranch: "a1l" }).exec(prod)
// }

// exports.findall_a1m = (prod) => {
//     Product.find({ productbranch: "a1m" }).exec(prod)
// }

// exports.findall_a1n = (prod) => {
//     Product.find({ productbranch: "a1n" }).exec(prod)
// }

// exports.findall_a1o = (prod) => {
//     Product.find({ productbranch: "a1o" }).exec(prod)
// }

// exports.findall_a1p = (prod) => {
//     Product.find({ productbranch: "a1p" }).exec(prod)
// }

// exports.findall_a2a = (prod) => {
//     Product.find({ productbranch: "a2a" }).exec(prod)
// }

// exports.findall_a2b = (prod) => {
//     Product.find({ productbranch: "a2b" }).exec(prod)
// }

// exports.findall_a2c = (prod) => {
//     Product.find({ productbranch: "a2c" }).exec(prod)
// }

// exports.findall_a2d = (prod) => {
//     Product.find({ productbranch: "a2d" }).exec(prod)
// }

// exports.findall_a2e = (prod) => {
//     Product.find({ productbranch: "a2e" }).exec(prod)
// }

// exports.findall_a2f = (prod) => {
//     Product.find({ productbranch: "a2f" }).exec(prod)
// }

// exports.findall_a2g = (prod) => {
//     Product.find({ productbranch: "a2g" }).exec(prod)
// }

// exports.findall_a2h = (prod) => {
//     Product.find({ productbranch: "a2h" }).exec(prod)
// }

// exports.findall_a2i = (prod) => {
//     Product.find({ productbranch: "a2i" }).exec(prod)
// }

// exports.findall_a2j = (prod) => {
//     Product.find({ productbranch: "a2j" }).exec(prod)
// }

// exports.findall_a2k = (prod) => {
//     Product.find({ productbranch: "a2k" }).exec(prod)
// }

// exports.findall_a3a = (prod) => {
//     Product.find({ productbranch: "a3a" }).exec(prod)
// }

// exports.findall_a3b = (prod) => {
//     Product.find({ productbranch: "a3b" }).exec(prod)
// }

// exports.findall_a3c = (prod) => {
//     Product.find({ productbranch: "a3c" }).exec(prod)
// }

// exports.findall_a3d = (prod) => {
//     Product.find({ productbranch: "a3d" }).exec(prod)
// }

// exports.findall_a3e = (prod) => {
//     Product.find({ productbranch: "a3e" }).exec(prod)
// }

// exports.findall_a3f = (prod) => {
//     Product.find({ productbranch: "a3f" }).exec(prod)
// }

// exports.findall_a3g = (prod) => {
//     Product.find({ productbranch: "a3g" }).exec(prod)
// }

// exports.findall_a3h = (prod) => {
//     Product.find({ productbranch: "a3h" }).exec(prod)
// }

// exports.findall_a3i = (prod) => {
//     Product.find({ productbranch: "a3i" }).exec(prod)
// }

// exports.findall_a3j = (prod) => {
//     Product.find({ productbranch: "a3j" }).exec(prod)
// }

// exports.findall_a3k = (prod) => {
//     Product.find({ productbranch: "a3k" }).exec(prod)
// }

// exports.findall_a3l = (prod) => {
//     Product.find({ productbranch: "a3l" }).exec(prod)
// }

// exports.findall_a3m = (prod) => {
//     Product.find({ productbranch: "a3m" }).exec(prod)
// }

// exports.findall_a4a = (prod) => {
//     Product.find({ productbranch: "a4a" }).exec(prod)
// }

// exports.findall_a4b = (prod) => {
//     Product.find({ productbranch: "a4b" }).exec(prod)
// }

// exports.findall_a4c = (prod) => {
//     Product.find({ productbranch: "a4c" }).exec(prod)
// }

// exports.findall_a4d = (prod) => {
//     Product.find({ productbranch: "a4d" }).exec(prod)
// }

// exports.findall_a4e = (prod) => {
//     Product.find({ productbranch: "a4e" }).exec(prod)
// }

// exports.findall_a4f = (prod) => {
//     Product.find({ productbranch: "a4f" }).exec(prod)
// }

// exports.findall_a4g = (prod) => {
//     Product.find({ productbranch: "a4g" }).exec(prod)
// }

// exports.findall_a4h = (prod) => {
//     Product.find({ productbranch: "a4h" }).exec(prod)
// }

// exports.findall_a4i = (prod) => {
//     Product.find({ productbranch: "a4i" }).exec(prod)
// }

// exports.findall_a4j = (prod) => {
//     Product.find({ productbranch: "a4j" }).exec(prod)
// }

// exports.findall_a4k = (prod) => {
//     Product.find({ productbranch: "a4k" }).exec(prod)
// }

// exports.findall_a5a = (prod) => {
//     Product.find({ productbranch: "a5a" }).exec(prod)
// }

// exports.findall_a5b = (prod) => {
//     Product.find({ productbranch: "a5b" }).exec(prod)
// }

// exports.findall_a5c = (prod) => {
//     Product.find({ productbranch: "a5c" }).exec(prod)
// }

// exports.findall_a5d = (prod) => {
//     Product.find({ productbranch: "a5d" }).exec(prod)
// }

// exports.findall_a6a = (prod) => {
//     Product.find({ productbranch: "a6a" }).exec(prod)
// }

// exports.findall_a6b = (prod) => {
//     Product.find({ productbranch: "a6b" }).exec(prod)
// }

// exports.findall_a6c = (prod) => {
//     Product.find({ productbranch: "a6c" }).exec(prod)
// }

// exports.findall_a6d = (prod) => {
//     Product.find({ productbranch: "a6d" }).exec(prod)
// }

// exports.findall_a7a = (prod) => {
//     Product.find({ productbranch: "a7a" }).exec(prod)
// }

// exports.findall_b1 = (prod) => {
//     Product.find({ productbranch: "b1" }).exec(prod)
// }

// exports.findall_b2 = (prod) => {
//     Product.find({ productbranch: "b2" }).exec(prod)
// }

// exports.findall_b3 = (prod) => {
//     Product.find({ productbranch: "b3" }).exec(prod)
// }

// exports.findall_b4 = (prod) => {
//     Product.find({ productbranch: "b4" }).exec(prod)
// }

// exports.findall_b5 = (prod) => {
//     Product.find({ productbranch: "b5" }).exec(prod)
// }

// exports.findall_c1 = (prod) => {
//     Product.find({ productbranch: "c1" }).exec(prod)
// }


// exports.findall_d = (prod) => {
//     Product.find({ productbranch: "d" }).exec(prod)
// }