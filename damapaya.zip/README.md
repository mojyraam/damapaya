# diselkala
# damapaya
