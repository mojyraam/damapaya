var express = require('express')
var router = express.Router()
var Products = require('../controllers/ProductsController')


router.get('/a1', (req, res) => { 
    //console.log(req.user._id)
    Products.list_a1(req, res)
})

router.get('/a2', (req, res) => { 
    Products.list_a2(req, res)
})

// router.get('/a1c', (req, res) => { 
//     Products.list_a1c(req, res)
// })

// router.get('/a1d', (req, res) => { 
//     Products.list_a1d(req, res)
// })

// router.get('/a1e', (req, res) => { 
//     Products.list_a1e(req, res)
// })

// router.get('/a1f', (req, res) => { 
//     Products.list_a1f(req, res)
// })

// router.get('/a1g', (req, res) => { 
//     Products.list_a1g(req, res)
// })

// router.get('/a1h', (req, res) => { 
//     Products.list_a1h(req, res)
// })

// router.get('/a1i', (req, res) => { 
//     Products.list_a1i(req, res)
// })

// router.get('/a1j', (req, res) => { 
//     Products.list_a1j(req, res)
// })

// router.get('/a1k', (req, res) => { 
//     Products.list_a1k(req, res)
// })

// router.get('/a1l', (req, res) => { 
//     Products.list_a1l(req, res)
// })

// router.get('/a1m', (req, res) => { 
//     Products.list_a1m(req, res)
// })

// router.get('/a1n', (req, res) => { 
//     Products.list_a1n(req, res)
// })

// router.get('/a1o', (req, res) => { 
//     Products.list_a1o(req, res)
// })

// router.get('/a1p', (req, res) => { 
//     Products.list_a1p(req, res)
// })

// router.get('/a2a', (req, res) => { 
//     Products.list_a2a(req, res)
// })

// router.get('/a2b', (req, res) => { 
//     Products.list_a2b(req, res)
// })

// router.get('/a2c', (req, res) => { 
//     Products.list_a2c(req, res)
// })

// router.get('/a2d', (req, res) => { 
//     Products.list_a2d(req, res)
// })

// router.get('/a2e', (req, res) => { 
//     Products.list_a2e(req, res)
// })

// router.get('/a2f', (req, res) => { 
//     Products.list_a2f(req, res)
// })

// router.get('/a2g', (req, res) => { 
//     Products.list_a2g(req, res)
// })

// router.get('/a2h', (req, res) => { 
//     Products.list_a2h(req, res)
// })

// router.get('/a2i', (req, res) => { 
//     Products.list_a2i(req, res)
// })

// router.get('/a2j', (req, res) => { 
//     Products.list_a2j(req, res)
// })

// router.get('/a2k', (req, res) => { 
//     Products.list_a2k(req, res)
// })

// router.get('/a3a', (req, res) => { 
//     Products.list_a3a(req, res)
// })

// router.get('/a3b', (req, res) => { 
//     Products.list_a3b(req, res)
// })

// router.get('/a3c', (req, res) => { 
//     Products.list_a3c(req, res)
// })

// router.get('/a3d', (req, res) => { 
//     Products.list_a3d(req, res)
// })

// router.get('/a3e', (req, res) => { 
//     Products.list_a3e(req, res)
// })

// router.get('/a3f', (req, res) => { 
//     Products.list_a3f(req, res)
// })
// router.get('/a3g', (req, res) => { 
//     Products.list_a3g(req, res)
// })

// router.get('/a3h', (req, res) => { 
//     Products.list_a3h(req, res)
// })

// router.get('/a3i', (req, res) => { 
//     Products.list_a3i(req, res)
// })

// router.get('/a3j', (req, res) => { 
//     Products.list_a3j(req, res)
// })

// router.get('/a3k', (req, res) => { 
//     Products.list_a3k(req, res)
// })

// router.get('/a3l', (req, res) => { 
//     Products.list_a3l(req, res)
// })

// router.get('/a3m', (req, res) => { 
//     Products.list_a3m(req, res)
// })

// router.get('/a4a', (req, res) => { 
//     Products.list_a4a(req, res)
// })

// router.get('/a4b', (req, res) => { 
//     Products.list_a4b(req, res)
// })

// router.get('/a4c', (req, res) => { 
//     Products.list_a4c(req, res)
// })

// router.get('/a4d', (req, res) => { 
//     Products.list_a4d(req, res)
// })

// router.get('/a4e', (req, res) => { 
//     Products.list_a4e(req, res)
// })

// router.get('/a4f', (req, res) => { 
//     Products.list_a4f(req, res)
// })

// router.get('/a4g', (req, res) => { 
//     Products.list_a4g(req, res)
// })

// router.get('/a4h', (req, res) => { 
//     Products.list_a4h(req, res)
// })

// router.get('/a4i', (req, res) => { 
//     Products.list_a4i(req, res)
// })

// router.get('/a4j', (req, res) => { 
//     Products.list_a4j(req, res)
// })

// router.get('/a4k', (req, res) => { 
//     Products.list_a4k(req, res)
// })

// router.get('/a5a', (req, res) => { 
//     Products.list_a5a(req, res)
// })

// router.get('/a5b', (req, res) => { 
//     Products.list_a5b(req, res)
// })

// router.get('/a5c', (req, res) => { 
//     Products.list_a5c(req, res)
// })

// router.get('/a5d', (req, res) => { 
//     Products.list_a5d(req, res)
// })

// router.get('/a6a', (req, res) => { 
//     Products.list_a6a(req, res)
// })

// router.get('/a6b', (req, res) => { 
//     Products.list_a6b(req, res)
// })

// router.get('/a6c', (req, res) => { 
//     Products.list_a6c(req, res)
// })

// router.get('/a6d', (req, res) => { 
//     Products.list_a6d(req, res)
// })

// router.get('/a7a', (req, res) => { 
//     Products.list_a7a(req, res)
// })

// router.get('/b1', (req, res) => { 
//     Products.list_b1(req, res)
// })

// router.get('/b2', (req, res) => { 
//     Products.list_b2(req, res)
// })

// router.get('/b3', (req, res) => { 
//     Products.list_b3(req, res)
// })

// router.get('/b4', (req, res) => { 
//     Products.list_b4(req, res)
// })

// router.get('/b5', (req, res) => { 
//     Products.list_b5(req, res)
// })

// router.get('/c1', (req, res) => { 
//     Products.list_c1(req, res)
// })

// router.get('/d', (req, res) => { 
//     Products.list_d(req, res)
// })

module.exports = router;
